<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends Marketing_Controller
{
    public function index()
    {
        marketing_enforce_canonical_path();
        $this->page_meta = array(
            'title'            => 'Your Mechanic Online | Car Service in Pune, Indore & Nashik',
            'meta_title'       => 'Your Mechanic Online | Car Service in Pune, Indore & Nashik',
            'meta_description' => 'Online car mechanic and multi-brand car garage in Pune, Indore & Nashik. Car service and repair with free pick-up from ₹2,499. Book Your Mechanic Online.',
            'h1'               => 'Your Mechanic Online — doorstep car service',
            'canonical_path'   => '',
            'quick_answer'     => 'Your Mechanic Online offers doorstep car servicing across Pune, Indore, and Nashik with free pick-up and drop, trained mechanics, transparent pricing from ₹2,499, and support on '.marketing_business_phone_display().'.',
            'og_image'         => '/assets/img/marketing/revslider/main/image_01.jpg',
        );
        $this->render_marketing('marketing/home', array(
            'booking_url'   => ymo_booking_url('packages'),
            'services'      => marketing_home_featured_services(),
            'city_strip'    => marketing_home_city_strip(),
            'brand_cards'   => marketing_home_brand_cards(),
            'benefits'      => $this->benefits(),
            'city_hint'     => NULL, // city hint now set client-side by assets/js/ymo-city.js
        ));
    }

    /** @return array<int, array{title:string,body:string,icon:string}> */
    private function benefits()
    {
        return array(
            array(
                'title' => 'Free doorstep pick-up & delivery',
                'body'  => 'Skip the garage queue - we collect your car, service it, and return it when done.',
                'icon'  => 'local_shipping',
            ),
            array(
                'title' => 'Transparent, competitive pricing',
                'body'  => 'Upfront estimates for hundreds of jobs. No surprise add-ons at billing time.',
                'icon'  => 'payments',
            ),
            array(
                'title' => 'Expert technicians',
                'body'  => 'Trained mechanics, modern equipment, and updates on WhatsApp with photos.',
                'icon'  => 'engineering',
            ),
        );
    }
}
