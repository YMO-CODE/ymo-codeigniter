<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * SEO consolidation 301s - thin/duplicate pages → canonical hubs.
 * Keys: path without leading slash. Values: new canonical path.
 */
return array(
    // Legacy city hubs → canonical /locations/{city}
    'book-car-servicing-in-pune' => 'locations/pune',
    'book-car-servicing-in-pune/' => 'locations/pune',
    'bestcar-services-indore-affordable-solutions' => 'locations/indore',
    'bestcar-services-indore-affordable-solutions/' => 'locations/indore',

    // Duplicate / legacy Pune listing pages
    'car-services-in-pune' => 'locations/pune',
    'car-services-in-pune/' => 'locations/pune',

    // Duplicate spares
    'ymo-car-spares-parts-india' => 'ymo-spares',
    'ymo-car-spares-parts-india/' => 'ymo-spares',

    // Luxury brand × locality → single luxury hub.
    // Phase 3: repoint BMW/Audi/Mercedes (and tag/*bmw*|*audi*|*mercedes*) to
    // /bmw-car-service-in-pune, /audi-car-service-in-pune, /mercedes-car-service-in-pune.
    'the-best-audi-servicing-in-bavdhan' => 'audi-car-service-in-pune',
    'the-best-audi-servicing-in-hinjewadi' => 'audi-car-service-in-pune',
    'the-best-audi-servicing-in-wakad' => 'audi-car-service-in-pune',
    'the-best-bmw-servicing-in-baner' => 'bmw-car-service-in-pune',
    'the-best-bmw-servicing-in-wakad' => 'bmw-car-service-in-pune',
    'the-best-mercedes-servicing-in-hinjewadi' => 'mercedes-car-service-in-pune',
    'the-best-mercedes-servicing-in-wakad' => 'mercedes-car-service-in-pune',
    'best-audi-servicing-in-aundh-pune' => 'audi-car-service-in-pune',
    'best-bmw-servicing-in-hinjewadi-luxury-car-care' => 'bmw-car-service-in-pune',
    'ymo-car-servicing-locations-in-pune/the-best-mercedes-servicing-in-viman-nagar' => 'mercedes-car-service-in-pune',

    // Nested WP hierarchy → flat locality or luxury hub
    'best-car-servicing-in-pune-ymo' => 'locations/pune',
    'best-car-servicing-in-pune-ymo/the-best-audi-servicing-in-viman-nagar' => 'affordable-car-services-viman-nagar-pune',
    'best-car-servicing-in-pune-ymo/the-best-mercedes-servicing-in-viman-nagar' => 'affordable-car-services-viman-nagar-pune',
    'best-car-servicing-in-pune-ymo/top-mercedes-servicing-aundh' => 'car-servicing-in-aundh',
    'best-car-servicing-in-pune-ymo/top-mercedes-servicing-baner' => 'the-best-car-servicing-in-baner',
    'best-car-servicing-in-pune-ymo/top-mercedes-servicing-baner/the-best-audi-servicing-baner-pune' => 'the-best-car-servicing-in-baner',
    'best-car-servicing-in-pune-ymo/top-mercedes-servicing-baner/the-best-audi-servicing-baner-pune/top-mercedes-servicing-in-bavdhan' => 'best-car-servicing-in-bavdhan-pune-expert-care',

    // Missing service pages → closest canonical service (not generic hub)
    'services/ceramic-coating-in-pune' => 'services/car-rubbing-and-polishing-in-pune-6500',
    'services/ceramic-coating-in-pune/' => 'services/car-rubbing-and-polishing-in-pune-6500',
    'services/car-tyre-and-wheel-services' => 'services/complete-car-servicing',
    'services/car-tyre-and-wheel-services/' => 'services/complete-car-servicing',
    'services/complete-car-servicing-in-pune' => 'services/complete-car-servicing',
    'services/complete-car-servicing-in-pune/' => 'services/complete-car-servicing',
    'services/car-brake-repair-in-pune' => 'services/car-brake-repair',
    'services/car-brake-repair-in-pune/' => 'services/car-brake-repair',
    'services/car-denting-and-painting-in-pune-3000' => 'services/car-denting-and-painting-3000',
    'services/car-denting-and-painting-in-pune-3000/' => 'services/car-denting-and-painting-3000',

    // Area x service stubs retired Nov 2026 (thin, no search demand) → main service page
    'car-ac-repair-in-baner' => 'services/car-air-conditioner-servicing-in-pune',
    'car-ac-repair-in-viman-nagar' => 'services/car-air-conditioner-servicing-in-pune',
    'car-polishing-in-hinjewadi' => 'services/car-rubbing-and-polishing-in-pune-6500',
    'car-brake-repair-in-aundh' => 'services/car-brake-repair',
    'car-denting-and-painting-in-wakad' => 'services/car-denting-and-painting-3000',

    // Interior cleaning price slug update (₹2000 → ₹2500)
    'services/car-interior-cleaning-in-indore-2000' => 'services/car-interior-cleaning-in-indore-2500',
    'services/car-interior-cleaning-in-indore-2000/' => 'services/car-interior-cleaning-in-indore-2500',
    'services/car-interior-cleaning-in-nashik-2000' => 'services/car-interior-cleaning-in-nashik-2500',
    'services/car-interior-cleaning-in-nashik-2000/' => 'services/car-interior-cleaning-in-nashik-2500',

    // Generic denting tags → denting service page (GSC: "denting painting" pos ~3, 0 clicks)
    'tag/car-denting-and-painting' => 'services/car-denting-and-painting-3000',
    'tag/car-denting-and-painting/' => 'services/car-denting-and-painting-3000',
    'tag/car-denting-painting-pune' => 'services/car-denting-and-painting-3000',
    'tag/car-denting-painting-pune/' => 'services/car-denting-and-painting-3000',
);
